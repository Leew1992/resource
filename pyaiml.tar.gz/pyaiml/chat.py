import aiml
import sys
from urllib.parse import parse_qs

def application(env, start_response):
    start_response('200 OK', [('Content-Type','text/html')])
    params = parse_qs(env['QUERY_STRING'])
    word = params.get('word', [''])[0]

    kern = aiml.Kernel()

    brainLoaded = False
    forceReload = False
    while not brainLoaded:
            if forceReload or (len(sys.argv) >= 2 and sys.argv[1] == "reload"):
                    kern.bootstrap(learnFiles="std-startup.xml", commands="load aiml b")
                    brainLoaded = True
                    kern.saveBrain("standard.brn")
            else:
                    try:
                            kern.bootstrap(brainFile="standard.brn")
                            brainLoaded = True
                    except:
                            forceReload = True
    responseMsg = kern.respond(word)
    print(responseMsg)
    return responseMsg
